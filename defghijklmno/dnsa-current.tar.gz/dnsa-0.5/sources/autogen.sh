#! /bin/sh

rm -f config.cache
rm -f config.log

aclocal
autoconf
autoheader
automake --gnu -a -c
