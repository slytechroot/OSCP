3.0 rc1 - 2014-02-21
====================

- release v.3.0 rc1

2.0 - 2014-02-20
================

- rewrite code and options
- detect ALIAS name
- automatic wildcard bypass
- resolve single domain

1.x - 2011
==========

- old version on Google Code -> http://code.google.com/p/knock/
