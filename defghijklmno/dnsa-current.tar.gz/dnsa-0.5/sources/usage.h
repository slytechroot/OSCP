#ifndef USAGE_H
#define USAGE_H

/* Modes available : -1 disabled ! */
#define MODE_DNS_ID_SPOOFING	0
#define MODE_DNS_ID_SNIFFING	1
#define MODE_DNS_POISONING	2

/* Error msg for incorrect args */
#define ERR_ARGS		"** Error : Can't stat args"

/* Maximum length for file names */
#define MAX_FILE_NAME_LONG	30

/* Functions */
void usage(char *progname);
void err_mem(void);
void err_mode(void);
void err_arg(void);
void err_long(char *type);
void err_arg_twice(char *err_type);

#endif
