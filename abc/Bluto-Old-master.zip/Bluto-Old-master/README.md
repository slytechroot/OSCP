**BLUTO**

Bluto has moved to a new repo, this version is now deprecated.

New version and repo can be found

https://github.com/darryllane/Bluto

**Latest Version Features:**

>DNS recon

>SubDomain Brute forcer

>DNZ Zone Transfers

>DNS Wild Card Checks

>DNS Wild Card Brute Forcing

>Email Enumeration

>Staff Enumeration

>Compromised Account Enumeration

>HTML Evidence Report

>Email Hunter API Support

>haveibeenpwned.com API Support

>Fast Geo Aware Google Searches

>Google Searches

>Bing Searches

>LinkedIn Searches

>MetaData Harvesting


Old Version
-----
**DNS recon | Brute forcer | DNS Zone Transfer | Email Enumeration**
 
>Author: Darryl Lane  |  Twitter: @darryllane101

>https://github.com/darryllane/Bluto-Old


