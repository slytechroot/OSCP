.. bro:id:: test_vector0

   :Type: :bro:type:`vector` of :bro:type:`string`
   :Default:

   ::

      []

   Yield type is documented/cross-referenced for primitize types.

.. bro:id:: test_vector1

   :Type: :bro:type:`vector` of :bro:type:`TestRecord`
   :Default:

   ::

      []

   Yield type is documented/cross-referenced for composite types.

.. bro:id:: test_vector2

   :Type: :bro:type:`vector` of :bro:type:`vector` of :bro:type:`TestRecord`
   :Default:

   ::

      []

   Just showing an even fancier yield type.

