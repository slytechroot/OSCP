#ifndef NETDEFS_H
#define NETDEFS_H

#define MAX_DOMAIN_LONG         70	/* Maximum length of domains */

#define MAX_IP_LONG             15	/* Maximum length of IPs (IPv4) */

#define MAX_FILTER_LONG		50+MAX_IP_LONG	/* For pcap filter */

#define MAX_INTERFACE_LONG	10	/* Maximum interface length (ethX, pppX, etc...) */

#define MAX_DNS_QUERY_LONG	80	/* Maximum length for FQDNs */

#define PROMISC_MODE		1	/* 0 : promisc mode disabled */
					/* 1 : promisc mode enabled */
#endif
