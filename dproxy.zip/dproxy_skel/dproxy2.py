#!/usr/bin/python2

import os # for output setting
import sys 

# turn off output buffer and set binary mode
sys.stdout = os.fdopen(sys.stdout.fileno(), 'wb', 0)

PATTERN = open("pattern2500.txt", 'rb', 0)
pattern = PATTERN.read()
PATTERN.close()
pattern = pattern.rstrip('\n')

buf = pattern

sys.stdout.write(buf)
