module Vcsmap
  module Plugin
  end
end
