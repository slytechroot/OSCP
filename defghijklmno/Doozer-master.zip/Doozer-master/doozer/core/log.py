ERROR = 1
LOG   = 2
