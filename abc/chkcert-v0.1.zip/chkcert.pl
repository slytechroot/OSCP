#!/usr/bin/env perl

use Modern::Perl;
use IO::Socket::SSL;
use Mozilla::CA;
use Getopt::Long;

my $host;
my $port;
my $verifymode = '0';

sub usage{
    say "Usage: chkcert.pl -h|--host <hostname> -p|--port <port number>";
    exit;
  }

usage() if ( ! GetOptions("h|host=s" => \$host, "p|port=s" => \$port) or ( ! defined $host) or ( ! defined $port) );

# Basic certificate checking
sub cert_info{
say "\nVerifying SSL Certificate...\n";
sleep 2;

my $certclient = IO::Socket::SSL->new(
  PeerHost => "$host:$port",
  SSL_ca_file => Mozilla::CA::SSL_ca_file(),
  SSL_verify_mode => $verifymode,
  SSL_version => 'TLSv1',
  SSL_cipher_list => 'RC4-SHA',
  Proto => 'tcp',
  Timeout => '5',
  ) 
    || die("Certificate Peer Verification Failed\n\nCertificate not trusted. This could be due to:\n  + An invalid certificate chain\n  + A self-signed certificate\n  + You are scanning the IP address and not the DNS hostname\n  + Host $host does not appear to be listening on port $port\n  + You misspelled the intended host to be scanned.\n  + The CA signing this cert is not trusted by your version of Mozilla::CA\n\n");

  $certclient->verify_hostname($host, "http")
    || die("Hostname Verification Failed.\n$host does not match certificate's common name.\n\n");
  say "Certificate appears to be valid.";
  my $cn = $certclient->peer_certificate("cn");
  if ( $cn eq "" ) {
    say "Certificate Common Name: none";
    }
    else {
      say "Certificate Commmon Name: " . $cn;
      }

  my @san = $certclient->peer_certificate("subjectAltNames");
  my $san_names = join(" ", grep { !( $_ eq 2 ) } @san);

  if ( $san_names eq "" ) {
    say "Subject Alternative Names: none";
    }
    else {
  say "Subject Alternative Names: " . $san_names;
  }
}

cert_info();
