from lib.utils.modules import modulelist 


class lists(modulelist):
    def __init__(self):
        modulelist.__init__(self)   
