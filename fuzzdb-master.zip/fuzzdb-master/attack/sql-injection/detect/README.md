
**MSSQL.fuzz.txt**

you will need to customize/modify some of the values in the payload queries for best effect






