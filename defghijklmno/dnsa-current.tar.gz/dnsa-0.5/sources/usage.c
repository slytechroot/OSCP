#include <stdio.h>
#include <stdlib.h>

#include "usage.h"

void usage(char *progname)
{
	printf("Usage: %s [OPTIONS]\n",progname);
	printf("Swiss knife tool for DNS auditing.\n\n");
	printf("-1\tDNS ID spoofing\t\t[ Required : -S ]\n");
	printf("\t-D [www.domain.org]\tHostname query to fool. Don't use it if every DNS request sniffed has to be spoofed\n");
	printf("\t-S [IP]\t\t\tIP address to send for DNS queries\n");
	printf("\t-s [IP]\t\t\tIP address of the host to fool\n");
	printf("\t-i [interface]\t\tIP address to send for DNS queries\n\n");
	printf("-2\tDNS IDs Sniffing\t[ Required : -s ] (Beta and not finished)\n");
	printf("\t-s [IP]\t\t\tIP address of the server which makes queries\n");
	printf("\t-w [file]\t\tOutput file for DNS IDs\n\n");
	printf("-3\tDNS cache poisoning\t[ Required : -S AND -a AND -b]\n");
	printf("\t-a [host.domain.org]\tHostname to send in the additional record\n");
	printf("\t-b [IP]\t\t\tIP to send in the additional record\n");
	printf("\t-D [www.domain.org]\tHostname for query. Use it if you want to fool just on\n");
	printf("\t-S [IP]\t\t\tIP address to send for DNS queries (the normal one)\n");
	printf("\t-s [IP]\t\t\tIP address of the server to fool\n");
	printf("\t-i [interface]\t\tIP address to send for DNS queries\n");
	
	printf("\n-h\tPrint usage\n");
	printf("\t\tBug reports to Pierre BETOUIN <soulrider@ifrance.com>\n");
	exit(0);
}

void err_mode(void)
{
	fprintf(stderr,"** Error : mode can be set once\n");
	exit(EXIT_FAILURE);
}

void err_mem(void)
{
	fprintf(stderr,"*** Error : memory\n");
	exit(EXIT_FAILURE);
}


void err_long(char *type)
{
	fprintf(stderr,"%s : string too long\n", type);
	exit(EXIT_FAILURE);
}

void err_arg_twice(char *errtype)
{
	fprintf(stderr,"** Error : %s arg cannot be set twice\n", errtype);
	exit(EXIT_FAILURE);
}

void err_arg(void)
{
	fprintf(stderr,"** Error : mode must be choosen before\n");
	exit(0);
}
