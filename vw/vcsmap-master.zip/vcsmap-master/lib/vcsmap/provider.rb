module Vcsmap
  module Provider
  end
end
