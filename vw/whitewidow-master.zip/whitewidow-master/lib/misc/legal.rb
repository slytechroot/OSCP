#
# Legal info, just to make sure that you know what's going on with this
#
module Legal

  class Legal

    #
    # Not entirely sure why I have this, this program isn't illegal. Better safe then sorry though.
    #
    def legal
      puts <<~_END_
         [ LEGAL DISCLAIMER ]

         I was written and created for learning purposes only, I should
         be treated as a tool to further your knowledge of how SQL queries
         work and what to look for so you don't become vulnerable, such as
         the sites you will find while using me. Using me for malicious
         purposes, including but not limited to:

                 - Blackhat database take overs, to exploit, deface, or
                   steal sensitive material.
                 - Black mailing the owners of the web pages
                 - Selling personal information found within the databases
                   of the websites discovered to be vulnerable
                 - Any and all malicious intents


         My owner Ekultek, takes no responsibility for the actions taken
         from the knowledge you have gained from using me.

         It is the end users responsibility to follow all laws, regulations,
         and rules of the state, territory, or country where I am being run.

         _________________________________________________________________

         [ TERMS OF SERVICE ]

         And now a note from my creator, the floor is all yours!

         Thank you by continuing with the processes of this program you
         agree, that all info discovered will be reported immediately to
         the owners of the web pages.

         Furthermore you agree that the owner and writer of this program,
         is not responsible for the actions taken upon the knowledge gained
         from use of this program, with or without prior approval from
         myself.

         You also agree that this program is being run to further your
         own personal knowledge of SQL. You will not use your new found
         knowledge to do any of the aforementioned illegal tasks.

         You agree that you are over the age of 18 years old and are
         legally considered an adult in your country or place of
         residence, and that you accept all responsibility for running
         this program.

         You agree to have your information given away freely if needs
         come. Meaning if I'm approached by the authorities, I will
         give away your information without question.

         Please take the time to read through the Legal Disclaimer and the
         Terms of Service.

         If for any reason you do not agree with the disclaimer, or terms,
         please exit this program immediately, and remove it from your
         device that it is being run on.

         Having said that, knowledge is not illegal, nor is the will to
         learn. Nobody can tell you that you aren't allowed to learn
         and nobody can tell you that what you learn is wrong.
         NEVER stop learning.

         I hope you take away as much from this program, as I gained from
         writing it.

         By continuing with this process you agree to the above terms and
         conditions and will are liable for your own actions.

         Press 'Enter' to continue..
           _END_
               .red.bold
      gets.chomp
    end

  end

end
