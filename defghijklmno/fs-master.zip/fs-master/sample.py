#!/usr/bin/env python
# coding=utf-8


from fs import *


print([one_by_one(0xffffc14c, 0xffffc6d0, 11)])
print([two_by_two(0xffffc14c, 0xffffc6d0, 11)])
