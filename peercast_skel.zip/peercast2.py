#!/usr/bin/python2

import os # for output setting
import sys

# turn off output buffer and set binary mode
sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', 0)

prefix = "GET /stream/?"
suffix = " HTTP/1.0\n\n"

PATTERN = open("pattern1000.txt", 'rb', 0)
pattern = PATTERN.read()
PATTERN.close()
pattern = pattern.rstrip('\n')

payload = prefix + pattern + suffix

sys.stdout.write(payload)
