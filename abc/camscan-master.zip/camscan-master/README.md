# camscan

Camscan is a tool which will analyze the CAM table of Cisco switches to
look for anamolies.

## License
Camscan is released under the BSD 3-clause license, for more details see
the [LICENSE](https://github.com/securestate/camscan/blob/master/LICENSE) file.
