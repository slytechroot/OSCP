"""
"""

# supported hashing methods
SUPPORTED_HASHES = [("nt", "nt"), ("lm", "lm")]
